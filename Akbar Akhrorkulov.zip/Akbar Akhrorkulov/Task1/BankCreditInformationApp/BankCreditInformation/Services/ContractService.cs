﻿using BankCreditInformation.Helpers;
using BankCreditInformation.Models;
using Newtonsoft.Json;
using System.Reflection;

namespace BankCreditInformation.Services;

public static class ContractService
{
    public static List<Contract> Contracts { get; } = new();
    
    private static IEnumerable<Type?> contractTypes = Assembly.GetExecutingAssembly()
        .GetTypes()
        .Where(t => t.IsSubclassOf(typeof(Contract)));

    static ContractService() => InitContracts();

    private static void InitContracts()
    {
        var jsonPath = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"JsonFile\Task1_loans.json");
        var jsonData = File.ReadAllText(jsonPath);  
        var contracts = JsonConvert.DeserializeObject<List<object>>(jsonData);

        if (contracts is null || contractTypes is null) return;

        foreach (var contract in contracts)
        {
            var currentContractObject = DeserializeContractObject(contract.ToString());
            if (currentContractObject is not null) 
                Contracts.Add(currentContractObject);
        }
    }

    public static void GetAllLoanTypes()
    {
        Console.WriteLine("\tContracts");   
        PrintContracts(Contracts);
    }

    public static void GetALlBanks()
    {
        var banks = Contracts.Select(x => x.Bank);
        Console.WriteLine("\tBanks");
        foreach (var bank in banks)
        {
            Console.WriteLine($"Bank id: {bank.Id}\n" +
                $"Bank name: {bank.Name}\n" +
                $"Bank address: {bank.Address}");
            Console.WriteLine(new string('-', 30));
        }
    }

    public static void GetAllBorrowers()
    {
        var borrowers = Contracts.Select(x => x.Borrower);
        Console.WriteLine("\tBorrowers");
        foreach (var borrower in borrowers)
        {
            Console.WriteLine($"Id: {borrower.Id}\n" +
                $"Full name: {borrower.FirstName} {borrower.LastName}\n" +
                $"PaasportNumber: {borrower.PaasportNumber}\n" +
                $"DateOfBirth: {borrower.DateOfBirth:dd/MM/yyyy}");
            Console.WriteLine(new string('-', 30));
        }
    }

    public static void GetAllTypesOfLoans()
    {
        Console.WriteLine("Press 1 to open AutoLoanContract");
        Console.WriteLine("Press 2 to open SquareLoanContract");
        Console.WriteLine("Press 3 to open UniversityLoanContract");
        var result = Console.ReadLine() switch  // here I tried to write switch statement in a new format 
        {
            "1" => Contracts.Where(x => x is AutoLoanContract),
            "2" => Contracts.Where(x => x is SquareLoanContract),
            "3" => Contracts.Where(x => x is UniversityLoanContract),
            _ => null
        };

        if (result is not null)
        {
            foreach (var item in result)
            {
                Console.WriteLine("\t"+item.GetType().Name);
                var props = item.GetType().GetProperties();
                foreach (var prop in props)
                {
                    var value = prop.GetValue(item);
                    Console.Write($"{prop.Name} = ");

                    if (prop.PropertyType == typeof(Bank) || prop.PropertyType == typeof(Borrower))
                    {
                        var subProps = prop.PropertyType.GetProperties();
                        foreach (var subProp in subProps)
                        {
                            var subValue = subProp.GetValue(value);
                            Console.Write($"{subProp.Name} = {(subValue is DateTime time ? time.ToString("dd/MM/yyyy") : subValue)}, ");
                        }
                        Console.WriteLine();
                    }
                    else
                    {
                        Console.WriteLine(value);
                    }

                }


                Console.WriteLine(new string('-',40));
            }
            return;
        }

        Console.WriteLine("none!");
    }

    public static void GetContractsWithLastName()
    {
        Console.WriteLine("Please enter the last name of the borrower");
        string lastName = Console.ReadLine() ?? string.Empty;
        var contracts = Contracts.Where(x => x.Borrower.LastName == lastName);
        Console.WriteLine($"\tLoan list by last name: {lastName}");
        PrintContracts(contracts);
    }

    public static void AddNewContract() 
    {
        Console.WriteLine("Please insert the path to json file with contract."); // as a an example i created Sample file with records in solution explorer.
        try
        {
            var jsonPathWithContract = Console.ReadLine() ?? string.Empty;
            var jsonData = File.ReadAllText(jsonPathWithContract);
            var contract = DeserializeContractObject(jsonData)
                ?? throw new Exception("Contract not found!");
            WriteNewContract(contract);
            if (contract != null)
            {
                Console.WriteLine("Records has been added successfully!");
                
            }
        }
        catch (Exception ex)
        {
            ConsoleWithColor.WriteLine(ex.Message, ConsoleColor.Red);
        }
    }

    public static void GetMothlyPaymentByLoanID()
    {
        Console.Write("Enter contract id: ");
        var contractId = long.Parse(Console.ReadLine() ?? string.Empty);
        var contract = Contracts.FirstOrDefault(x => x.Id == contractId);
        if (contract is null)
        {
            Console.WriteLine("contract not found");
            return;
        }

        var monthlyPayment = CalculateMonthlyPayment(contract.Amount, contract.Percent, contract.CountOfMonth);
        ConsoleWithColor.WriteLine($"monthlyPayment => {monthlyPayment}", ConsoleColor.Green);
    }

    private static Contract? DeserializeContractObject(string? jsonData)
    {
        if (jsonData is null || jsonData == string.Empty) return null;

        foreach (var contractType in contractTypes)
        {
            try
            {
                var deserializeSettings = new JsonSerializerSettings()
                {
                    MissingMemberHandling = MissingMemberHandling.Error,
                    ContractResolver = new RequiredPropertiesContractResolver()
                };

                var currentContractObject = JsonConvert.DeserializeObject(jsonData, contractType, deserializeSettings);
                
                var contract = currentContractObject as Contract ?? throw new Exception();
                return contract;
            }
            catch { } // ignored
        }

        return null;
    }

    private static void WriteNewContract(Contract contract)
    {
        Contracts.Add(contract);
        string json = JsonConvert.SerializeObject(Contracts, Formatting.Indented);
    }

    private static void PrintContracts(IEnumerable<Contract>? contracts)
    {
        if (contracts is null || !contracts.Any())
        {
            Console.WriteLine("None!"); 
            return;
        }

        foreach (var contract in contracts)
        {
            Console.WriteLine($"Loan Type: {contract.GetType().Name}\n" +
                $"Id: {contract.Id}\n" +
                $"Amount: {contract.Amount}\n" +
                $"Percent: {contract.Percent}\n" +
                $"CountOfMonth: {contract.CountOfMonth}\n" +
                $"Name of the Bank: {contract.Bank?.Name}\n" +
                $"Full Name: {contract.Borrower?.LastName} {contract.Borrower?.FirstName}");
            Console.WriteLine(new string('-', 30));
        }
    }

    private static double CalculateMonthlyPayment(double amount, double percent, int countOfMonth)
    {
        double monthlyInterestRate = (percent / 100) / 12;
        double annuityFactor = (monthlyInterestRate * Math.Pow(1 + monthlyInterestRate, countOfMonth)) 
                               /
                               (Math.Pow(1 + monthlyInterestRate, countOfMonth) - 1);

        double monthlyPayment = amount * annuityFactor;

        return monthlyPayment;
    }
}
