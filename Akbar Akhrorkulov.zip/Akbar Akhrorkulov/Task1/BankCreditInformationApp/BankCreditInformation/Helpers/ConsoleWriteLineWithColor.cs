﻿namespace BankCreditInformation.Helpers
{
    public static class ConsoleWithColor
    {
        public static void WriteLine(string text, ConsoleColor consoleColor)
        {
            var currentColor = Console.ForegroundColor;
            Console.ForegroundColor = consoleColor;
            Console.WriteLine(text);
            Console.ForegroundColor = currentColor;
        }
    }
}
