﻿using BankCreditInformation.Helpers;
using BankCreditInformation.Services;

namespace BankCreditInformation
{
    public class Program
    {
        static void Main(string[] args)
        {
            ConsoleWithColor.WriteLine("Welcome to the bank loan agreements application!", ConsoleColor.Magenta);
            var isRunning = true;
            while (isRunning)
            {
                ConsoleWithColor.WriteLine("Press 1 to get information about all types of loans.", ConsoleColor.DarkYellow);
                ConsoleWithColor.WriteLine("Press 2 to get a list of all banks.", ConsoleColor.DarkYellow);
                ConsoleWithColor.WriteLine("Press 3 to get a list of all borrowers.", ConsoleColor.DarkYellow);
                ConsoleWithColor.WriteLine("Press 4 to get the list of loans by the specified type (AutoLoanContract, SquareLoanContract, UniversityLoanContract).", ConsoleColor.DarkYellow);
                ConsoleWithColor.WriteLine("Press 5 to add a new loan.", ConsoleColor.DarkYellow);
                ConsoleWithColor.WriteLine("Press 6 to get a list of loans by the borrower’s Last Name.", ConsoleColor.DarkYellow);
                ConsoleWithColor.WriteLine("Press 7 to calculate monthly annuity payment for a given loan ID.", ConsoleColor.DarkYellow);
                

                ConsoleWithColor.WriteLine("Press 'E' to exit.\n", ConsoleColor.DarkYellow);
                var input = Console.ReadLine();
                switch (input)
                {
                    case "1":
                        ContractService.GetAllLoanTypes();
                        break;
                    case "2":
                        ContractService.GetALlBanks();
                        break;
                    case "3":
                        ContractService.GetAllBorrowers();
                        break;
                    case "4":
                        ContractService.GetAllTypesOfLoans();
                        break;
                    case "5":
                        ContractService.AddNewContract();
                        break;
                    case "6":
                        ContractService.GetContractsWithLastName();
                        break;
                    case "7":
                        ContractService.GetMothlyPaymentByLoanID();
                        break;
                    case "e" or "E":
                        isRunning = false;
                        break;
                    default:
                        ConsoleWithColor.WriteLine("Invalid input. Please select a number from 1 to 7.", ConsoleColor.Red);
                        break;
                };
            }
        }
    }
}
