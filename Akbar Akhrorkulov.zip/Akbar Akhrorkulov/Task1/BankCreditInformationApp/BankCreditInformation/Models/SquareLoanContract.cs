﻿namespace BankCreditInformation.Models
{
    public class SquareLoanContract : Contract
    {
        public string AddressOfObject { get; set; }
        public double Square { get; set; }
    }
}
    