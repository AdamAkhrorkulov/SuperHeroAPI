﻿using Newtonsoft.Json;

namespace BankCreditInformation.Models
{
    public class AutoLoanContract : Contract
    {
        public string CarModel { get; set; }
        public string CarBrand { get; set; }
        public string VIN { get; set; }
    }
}
    