﻿namespace BankCreditInformation.Models
{
    public abstract class Contract
    {
        public long Id { get; set; }
        public double Amount { get; set; }
        public ushort CountOfMonth { get; set; }
        public double Percent { get; set; }
        public Borrower Borrower { get; set; }
        public Bank Bank { get; set; } 
    }
}
