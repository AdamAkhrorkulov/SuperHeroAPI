﻿using BankCreditInformation.Helpers;
using Newtonsoft.Json;

namespace BankCreditInformation.Models
{
    public class Borrower
    {
        public long Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        [JsonConverter(typeof(CustomDateTimeConverter))]
        public DateTime DateOfBirth { get; set; }
        public string PaasportNumber { get; set; }
    }
}
