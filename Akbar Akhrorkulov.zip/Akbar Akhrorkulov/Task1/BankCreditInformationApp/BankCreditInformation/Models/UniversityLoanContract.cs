﻿using Newtonsoft.Json;

namespace BankCreditInformation.Models
{
    public class UniversityLoanContract : Contract
    {
        public string UniversityName { get; set; }

        public string UniversityAddress { get; set; }
    }
}
    