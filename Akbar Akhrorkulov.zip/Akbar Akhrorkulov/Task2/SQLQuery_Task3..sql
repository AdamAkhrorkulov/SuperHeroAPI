use Library

SELECT
    LiteraryWorks.Title,
    Authors.Name as AuthorName,
    LiteraryWorks.YearOfWriting
FROM
    LiteraryWorks
JOIN Authors ON LiteraryWorks.AuthorID = Authors.Id
WHERE
    LiteraryWorks.Id IN (
        SELECT LiteraryWorkID FROM LiteraryWorks_Books
        GROUP BY LiteraryWorkID)
ORDER BY Authors.Name ASC, LiteraryWorks.YearOfWriting ASC;

