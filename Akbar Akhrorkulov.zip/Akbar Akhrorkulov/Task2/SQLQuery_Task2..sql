use Library

SELECT
    a.LastName,
    a.FirstName,
    COUNT(DISTINCT e.Id) AS Count
FROM
    Readers a
JOIN BookLoans b ON a.Id = b.ReaderID
JOIN BookCopies c ON b.BookCopyID = c.BookId
JOIN LiteraryWorks_Books d ON d.BookID = c.BookID
JOIN LiteraryWorks as e ON d.LiteraryWorkID = e.Id

GROUP BY a.LastName, a.FirstName
ORDER BY Count DESC;



	