use Library

;WITH CalcLoanDays AS (   
    SELECT
        lw.AuthorId,
        lw.Title,
        SUM(DATEDIFF(DAY, bl.LoanDate, bl.ReturnDate)) AS LoanDays
    FROM
        LiteraryWorks lw
    JOIN LiteraryWorks_Books lwb ON lw.Id = lwb.LiteraryWorkId
    JOIN BookCopies bc ON bc.Id = lwb.BookId
    JOIN BookLoans bl ON bc.Id = bl.BookCopyId
    GROUP BY lw.AuthorId, lw.Title
),
TopBooksPerAuthors AS (
    SELECT
		lw.AuthorId,
        lw.Title,
        ROW_NUMBER() OVER (PARTITION BY lw.AuthorId ORDER BY SUM(wld.LoanDays) DESC) AS TopRank
    FROM
        CalcLoanDays wld
    JOIN LiteraryWorks lw ON wld.AuthorId = lw.AuthorId AND wld.Title = lw.Title
    GROUP BY lw.AuthorId, lw.Title
	HAVING sum(wld.LoanDays) !=0
)
SELECT
    --ROW_NUMBER() OVER (ORDER BY a.Name) AS RowId,
    a.Name AS AuthorName,
    SUM(cld.LoanDays) AS CountAll,
    STRING_AGG(ta.Title, ', ') AS Top3
FROM
    Authors a
JOIN TopBooksPerAuthors ta ON a.Id = ta.AuthorId
JOIN CalcLoanDays cld ON ta.AuthorId = cld.AuthorId AND ta.Title = cld.Title
WHERE
--cld.LoanDays !=0 and
ta.TopRank <= 3
GROUP BY a.Name
ORDER BY 2 desc;