use Library

SELECT
    Authors.Name [AuthorName],
    COUNT(LiteraryWorks.Id) AS [NumberOfBookWorks]
FROM
    Authors
JOIN LiteraryWorks ON Authors.Id = LiteraryWorks.AuthorID

GROUP BY Authors.Name
ORDER BY [NumberOfBookWorks] DESC;
