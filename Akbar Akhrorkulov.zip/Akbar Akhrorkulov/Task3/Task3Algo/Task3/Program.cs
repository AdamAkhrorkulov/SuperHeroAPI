﻿using System;
using System.IO;
using System.Reflection;


public class Program
{
    static int[,] GetInputMatrix()
    {
        int N = 20; // Размерность таблицы
        int[,] matrix = new int[N, N];
        var filename = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"Task3_input.txt");

        using (var reader = new StreamReader(filename))
        {
            string[] line = reader.ReadLine().Split(' ');
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    matrix[i, j] = int.Parse(line[j]);
                }
            }
        }

        return matrix;
    }
    static void Main()
    {
        var matrix = GetInputMatrix();

        // Enter value for M
        Console.WriteLine("Enter value for M (1 ≤ M ≤ 6 и M ≤ N):");
        int M = int.Parse(Console.ReadLine());

        if (M < 1 || M > 6)
        {
            Console.WriteLine("M input has to be from 1 to 6.");
            return;
        }
        if (M > 20)
        {
            Console.WriteLine("M cannot be greater than 20.");
            return;
        }

        FindMaxSum(matrix, M);

        FindMaxProduct(matrix, M);
    }

    static void FindMaxSum(int[,] matrix, int M)
    {
        int maxSum = int.MinValue;
        int[] indexes = new int[2];

        for (int i = 0; i <= 20 - M; i++)
        {
            for (int j = 0; j <= 20 - M; j++)
            {
                int sum = 0;
                for (int k = 0; k < M; k++)
                {
                    sum += matrix[i, j + k];
                }
                if (sum > maxSum)
                {
                    maxSum = sum;
                    indexes[0] = i;
                    indexes[1] = j;
                }
            }
        }

        Console.WriteLine($"Max sum {M} for consecutive numbers: {maxSum}");
        Console.WriteLine("Indices of element:");
        for (int i = 0; i < M; i++)
        {
            Console.WriteLine($"({indexes[0]}, {indexes[1] + i})");
        }
    }

    static void FindMaxProduct(int[,] matrix, int M)
    {
        long maxProduct = long.MinValue;
        int[] indexes = new int[2];

        for (int i = 0; i <= 20 - M; i++)
        {
            for (int j = 0; j <= 20 - M; j++)
            {
                long product = 1;
                for (int k = 0; k < M; k++)
                {
                    product *= matrix[i, j + k];
                }
                if (product > maxProduct)
                {
                    maxProduct = product;
                    indexes[0] = i;
                    indexes[1] = j;
                }
            }
        }

        Console.WriteLine($"Max product {M} for consecutive numbers: {maxProduct}");
        Console.WriteLine("Indices of element:");
        for (int i = 0; i < M; i++)
        {
            Console.WriteLine($"({indexes[0]}, {indexes[1] + i})");
        }
    }
}