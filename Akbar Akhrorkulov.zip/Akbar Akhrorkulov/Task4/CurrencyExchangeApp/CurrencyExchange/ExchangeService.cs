﻿using CurrencyExchange.Models;
using System.Globalization;
using System.Text.Json;

namespace CurrencyExchange;

public class ExchangeService : IExchangeService
{
    private readonly HttpClient _client;

    public ExchangeService()
    {
        _client = new HttpClient();
        _client.DefaultRequestHeaders.Add("apikey", "fca_live_dVxmXku1eMJpqFyWBXyafUEvGx408e2iiWo14MLh");
        _client.BaseAddress = new Uri("https://api.freecurrencyapi.com");
    }

    public async Task<Dictionary<string, Currency>> GetCurrencies()
    {
        var response = await _client.GetAsync("/v1/currencies");
        string responseData = await response.Content.ReadAsStringAsync();
        var currency = JsonSerializer.Deserialize<CurrencyResponse>(responseData);
        return currency.CurrencyResponseData;
    }
        
    public async Task<decimal> Exchange(string fromCurrency, string toCurrency, decimal amount)
    {
        var response = await _client.GetAsync($"/v1/latest?base_currency={fromCurrency}&currencies={toCurrency}");
        string responseData = await response.Content.ReadAsStringAsync();
        var currency = JsonSerializer.Deserialize<ExchangeRates>(responseData);
        var result = currency.ExchangeData.First().Value * amount;
        return result;
    }

    public async Task<decimal> HistoricalExchange(string fromCurrency, string toCurrency, decimal amount, DateTime date)
    {
        var dateString = date.ToString("yyyy-MM-dd");
        var response = await _client.GetAsync($"/v1/historical?date={dateString}&base_currency={fromCurrency}&currencies={toCurrency}");
        var responseData = await response.Content.ReadAsStringAsync();
        var currency = JsonSerializer.Deserialize<HistoricalExchangeRates>(responseData);
        var result = currency.HistoricalExchangeData
            .FirstOrDefault(x => x.Key == date.ToString("yyyy-MM-dd")).Value
            .FirstOrDefault(x => x.Key == toCurrency).Value 
                     * amount;

        return result;
    }
}   