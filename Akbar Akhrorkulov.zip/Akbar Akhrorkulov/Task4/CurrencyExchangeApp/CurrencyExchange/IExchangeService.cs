﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CurrencyExchange.Models;

namespace CurrencyExchange
{
    public interface IExchangeService
    {
        Task<Dictionary<string, Currency>> GetCurrencies();
        Task<decimal> Exchange(string fromCurrency, string toCurrency, decimal amount);
        Task<decimal> HistoricalExchange(string fromCurrency, string toCurrency, decimal amount, DateTime date);
    }
}
    