﻿using CurrencyExchange.Models;
using System;
using System.Globalization;
using System.Linq;

namespace CurrencyExchange
{
    public class Program
    {
        static async Task Main(string[] args)
        {
            var exchangeService = new ExchangeService();
            var currencies = await exchangeService.GetCurrencies();

            while (true)
            {
                Console.WriteLine("\nWelcome to the Currency Exchange console application");
                Console.WriteLine("Please choose an action:");
                Console.WriteLine("1. Display all available currencies");
                Console.WriteLine("2. Make an exchange of one currency into another");
                Console.WriteLine("3. Make an exchange of one currency into another on a specified date in the past");
                Console.WriteLine("0. Exit the console application");

                int choice;

                if (!int.TryParse(Console.ReadLine(), out choice))
                {
                    Console.WriteLine("Invalid input. Please select a number from 0 to 3.");
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Available currencies:");
                        foreach (var currency in currencies)
                        {
                            Console.WriteLine($"{currency.Value.Code} | {currency.Value.Name}");
                        }
                        break;
                    case 2:
                        await MakeExchange(exchangeService);
                        break;
                    case 3:
                        await MakeHistoricalExchange(exchangeService, currencies);
                        break;
                    case 0:
                        return;
                    default:
                        Console.WriteLine("Invalid input. Please select a number from 0 to 3.");
                        break;
                }
            }
        }

        static async Task MakeExchange(ExchangeService exchangeService)
        {
            var currencies = await exchangeService.GetCurrencies();
            Console.WriteLine("Enter the currency code from which the exchange is made:");
            string fromCurrency = Console.ReadLine().ToUpper();
            if (!currencies.ContainsKey(fromCurrency))
            {
                Console.WriteLine("Error: this currency does not exist!");
                return;
            }

            Console.WriteLine("Enter the currency code in which you want to exchange:");
            string toCurrency = Console.ReadLine().ToUpper();
            if (!currencies.ContainsKey(toCurrency))
            {
                Console.WriteLine("Error: this currency does not exist!");
                return;
            }

            Console.WriteLine("Enter the number to exchange:");
            decimal amount;
            if (!decimal.TryParse(Console.ReadLine(), out amount))
            {
                Console.WriteLine("Invalid input. Please enter number.");
                return;
            }

            try
            {
                decimal result = await exchangeService.Exchange(fromCurrency, toCurrency, amount);
                Console.WriteLine($"Result of the exchange: {result} {toCurrency}");
            }
            catch (HttpRequestException)
            {
                Console.WriteLine("An error occurred while making an API request.");
            }
        }

        static async Task MakeHistoricalExchange(ExchangeService exchangeService, Dictionary<string, Currency> currencies)
        {
            Console.WriteLine("Enter the date in YYYY-MM-DD format:");
            DateTime date;
            var input = Console.ReadLine();
            if (!DateTime.TryParseExact(input, "yyyy-MM-dd", CultureInfo.InvariantCulture,DateTimeStyles.None, out date))
            {
                Console.WriteLine("Invalid input. Please enter the date in the correct format.");
                return;
            }

            Console.WriteLine("Enter the currency code from which the exchange is made:");
            string fromCurrency = Console.ReadLine().ToUpper();
            if (!currencies.ContainsKey(fromCurrency))
            {
                Console.WriteLine("Error: this currency does not exist!");
                return;
            }

            Console.WriteLine("Enter the currency code in which you want to exchange:");
            string toCurrency = Console.ReadLine().ToUpper();
            if (!currencies.ContainsKey(toCurrency))
            {
                Console.WriteLine("Error: this currency does not exist!");
                return;
            }

            Console.WriteLine("Enter the number to exchange:");
            decimal amount;
            if (!decimal.TryParse(Console.ReadLine(), out amount))
            {
                Console.WriteLine("Invalid input. Please enter number.");
                return;
            }

            try
            {
                decimal result = await exchangeService.HistoricalExchange(fromCurrency, toCurrency, amount, date);
                Console.WriteLine($"Result of the exchange on date {date.ToString("yyyy MMMM dd")}: {result} {toCurrency}");
            }
            catch (HttpRequestException)
            {
                Console.WriteLine("An error occurred while making an API request.");
            }
        }
    }
}
