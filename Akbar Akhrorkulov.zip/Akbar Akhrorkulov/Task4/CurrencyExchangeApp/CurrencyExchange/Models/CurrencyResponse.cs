﻿using System.Text.Json.Serialization;

namespace CurrencyExchange.Models;

public class CurrencyResponse
{
    [JsonPropertyName("data")]
    public Dictionary<string, Currency>? CurrencyResponseData { get; set; }
}       