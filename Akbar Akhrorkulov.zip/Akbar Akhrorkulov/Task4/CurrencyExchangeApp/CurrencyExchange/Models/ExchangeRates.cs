﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CurrencyExchange.Models
{
    public class ExchangeRates
    {
        [JsonPropertyName("data")]
        public Dictionary<string, decimal>? ExchangeData { get; set; }
    }
}
            