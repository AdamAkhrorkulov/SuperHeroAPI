﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CurrencyExchange.Models
{
    public class HistoricalExchangeRates
    {
        [JsonPropertyName("data")]
        public Dictionary<string, Dictionary<string, decimal>>? HistoricalExchangeData { get; set; }
    }
}
                