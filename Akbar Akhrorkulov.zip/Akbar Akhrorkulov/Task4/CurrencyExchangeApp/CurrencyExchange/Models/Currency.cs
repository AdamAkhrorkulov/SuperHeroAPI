﻿using System.Text.Json.Serialization;

namespace CurrencyExchange.Models;

public class Currency
{
    [JsonPropertyName("symbol")]
    public string Symbol { get; set; }

    [JsonPropertyName("name")]
    public string Name { get; set; }

    [JsonPropertyName("symbol_native")]
    public string SymbolNative { get; set; }

    [JsonPropertyName("decimal_digits")]
    public int DecimalDigits { get; set; }

    [JsonPropertyName("rounding")]
    public int Rounding { get; set; }

    [JsonPropertyName("code")]
    public string Code { get; set; }

    [JsonPropertyName("name_plural")]
    public string NamePlural { get; set; }

    [JsonPropertyName("type")]
    public string Type { get; set; }
}       